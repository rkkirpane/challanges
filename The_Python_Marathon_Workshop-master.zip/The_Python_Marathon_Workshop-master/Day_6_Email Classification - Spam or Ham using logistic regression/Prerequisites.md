# Prerequisites!

**Following are the prerequisites:**

   - Pandas
   - Numpy
   - Matplotlib
   - Inferential and Descriptive Statistics
   - PCA
   - Sklearn

Be prepared so that you can take most out of this session!
All the best!
