**Contents of the repository:**

  **data folder** : Contains all the required data

  **notebook folder** : Contains the jupyter notebook to be used
